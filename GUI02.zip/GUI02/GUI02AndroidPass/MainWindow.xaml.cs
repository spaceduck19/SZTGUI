﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GUI02AndroidPass
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool selectionStarted;
        private string code = "74123";
        private string inputcode = "";
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Source is Label l && selectionStarted)
            {
                l.Background = Brushes.Yellow;
                if (!inputcode.Contains(l.Tag.ToString()))
                {
                    inputcode += l.Tag.ToString();
                }
            }
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            selectionStarted = true;
        }

        private void Window_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            selectionStarted = false;

            if (code == inputcode)
            {
                MessageBox.Show("Sikerült belépned!");
            }


            for (int i = 0; i < mygrid.Children.Count; i++)
            {
                if (mygrid.Children[i] is Label l)
                {
                    l.Background = Brushes.LightBlue;
                }
            }
            inputcode = "";
        }
    }
}
