﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Media;

namespace ChickenFarmMego.Utils
{
    internal class EggsToBrushConverter : IValueConverter
    {
        // forrás (tojások száma) --> cél (UI elem háttérszíne)
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            int eggs = (int)value;
            return eggs > 0 ? Brushes.LightGreen : Brushes.White;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return Binding.DoNothing;
        }
    }
}
