﻿using ChickenFarmMego.Logic;
using ChickenFarmMego.Models;
using ChickenFarmMego.Services;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChickenFarmMego.ViewModels
{
    internal partial class MainWindowViewModel : ObservableRecipient
    {
        IFarmLogic logic;
        // { get { return logic.....; } }
        public List<Chicken> Chickens { get => logic.Chickens; }
        public int GatheredEggs => logic.GatheredEggs;

        [ObservableProperty]
        [NotifyCanExecuteChangedFor(nameof(AddFoodCommand))]
        [NotifyCanExecuteChangedFor(nameof(EditChickenCommand))]
        Chicken selectedChicken;

        public MainWindowViewModel(IFarmLogic logic)
        {
            this.logic = logic;
        }

#if DEBUG
        public MainWindowViewModel()
            : this(new FarmLogic(new EditService()))
        { }
#endif

        bool CanExecuteAction()
        {
            return SelectedChicken != null;
        }

        //[RelayCommand(CanExecute = "CanExecuteAction")]
        [RelayCommand(CanExecute = nameof(CanExecuteAction))]
        public void AddFood()
        {
            logic.AddFood(SelectedChicken);
        }

        [RelayCommand]
        public void TakeEggs()
        {
            logic.TakeEggs();
            OnPropertyChanged(nameof(GatheredEggs));
        }

        [RelayCommand(CanExecute = nameof(CanExecuteAction))]
        public void EditChicken()
        {
            logic.EditChicken(SelectedChicken);
        }
    }
}
