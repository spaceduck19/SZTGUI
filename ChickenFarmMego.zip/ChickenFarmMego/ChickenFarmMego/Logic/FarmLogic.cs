﻿using ChickenFarmMego.Models;
using ChickenFarmMego.Services;
using CommunityToolkit.Mvvm.ComponentModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChickenFarmMego.Logic
{
    internal partial class FarmLogic : ObservableObject, IFarmLogic
    {
        [ObservableProperty]
        List<Chicken> chickens;
        [ObservableProperty]
        int gatheredEggs;

        IEditService editService;

        public FarmLogic(IEditService editService)
        {
            this.editService = editService;

            this.chickens = new List<Chicken>()
            {
                new Chicken("Aranka"),
                new Chicken("Kotkoda"),
                new Chicken("Rozsdás"),
            };
        }

        public void AddFood(Chicken chicken)
        {
            chicken.EatFood();
        }

        public void EditChicken(Chicken chicken)
        {
            this.editService.Edit(chicken);
        }

        public void TakeEggs()
        {
            foreach (var chicken in this.Chickens)
            {
                this.GatheredEggs += chicken.GiveEggs();
            }
        }
    }
}
