﻿using ChickenFarmMego.Models;

namespace ChickenFarmMego.Logic
{
    internal interface IFarmLogic
    {
        List<Chicken> Chickens { get; }
        int GatheredEggs { get; }
        void AddFood(Chicken chicken);
        void TakeEggs();
        void EditChicken(Chicken chicken);
    }
}
