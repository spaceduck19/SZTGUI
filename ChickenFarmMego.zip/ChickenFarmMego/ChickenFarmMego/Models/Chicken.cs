﻿using CommunityToolkit.Mvvm.ComponentModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChickenFarmMego.Models
{
    public partial class Chicken : ObservableObject
    {
        [ObservableProperty]
        string name;

        [ObservableProperty]
        int eggs;

        public Chicken(string name)
        {
            this.name = name;
            this.eggs = 0;
        }

        public void EatFood()
        {
            Random r = new Random();

            this.Eggs += r.Next(2, 6);
        }

        public int GiveEggs()
        {
            int producedEggs = this.Eggs;
            this.Eggs = 0;
            return producedEggs;
        }
    }
}
