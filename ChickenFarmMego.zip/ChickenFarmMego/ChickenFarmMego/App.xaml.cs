﻿using ChickenFarmMego.Logic;
using ChickenFarmMego.Services;
using CommunityToolkit.Mvvm.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using System.Configuration;
using System.Data;
using System.Windows;

namespace ChickenFarmMego
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        // ne felejtsük el, konstruktor!!
        public App()
        {
            Ioc.Default.ConfigureServices(
                new ServiceCollection()
                // szolgáltatások felsorolása ide!
                .AddTransient<IFarmLogic, FarmLogic>()
                .AddTransient<IEditService, EditService>()
                .BuildServiceProvider()
                );
        }
    }

}
