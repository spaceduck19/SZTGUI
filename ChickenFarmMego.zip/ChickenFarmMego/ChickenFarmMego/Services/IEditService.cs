﻿using ChickenFarmMego.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChickenFarmMego.Services
{
    internal interface IEditService
    {
        bool Edit(Chicken chicken);
    }
}
