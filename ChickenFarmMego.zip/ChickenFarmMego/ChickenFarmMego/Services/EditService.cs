﻿using ChickenFarmMego.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Ink;

namespace ChickenFarmMego.Services
{
    internal class EditService : IEditService
    {
        public bool Edit(Chicken chicken)
        {
            EditWindow ew = new EditWindow(chicken);
            return ew.ShowDialog() == true;
        }
    }
}
