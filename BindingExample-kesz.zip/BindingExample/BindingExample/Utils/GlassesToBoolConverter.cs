﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace BindingExample.Utils
{
    internal class GlassesToBoolConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string glassesStr = value as string ?? "nincs";
            return glassesStr == "van";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool haveGlasses = (bool)value;
            return haveGlasses ? "van" : "nincs";
        }
    }
}
