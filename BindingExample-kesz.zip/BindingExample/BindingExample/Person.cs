﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace BindingExample
{
    internal partial class Person : ObservableObject
    {
        [ObservableProperty]
        string name;
        [ObservableProperty]
        int age;
        [ObservableProperty]
        string haveGlasses; // "van", "nincs"

        public override string ToString()
        {
            return $"{Name} ({Age}), szemüveg: {HaveGlasses}";
        }

        public void ChangeGlasses()
        {
            if (HaveGlasses == "van")
                HaveGlasses = "nincs";
            else
                HaveGlasses = "van";
        }
    }
}
