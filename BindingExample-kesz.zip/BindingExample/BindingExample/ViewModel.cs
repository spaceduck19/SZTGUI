﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BindingExample
{
    internal class ViewModel
    {
        public BindingList<Person> People { get; set; }

        public ViewModel()
        {
            this.People = new BindingList<Person>()
            {
                new Person() { Name="Pista", Age=27, HaveGlasses="nincs"},
                new Person() { Name="Evelin", Age=23, HaveGlasses="nincs"},
                new Person() { Name="Géza", Age=25, HaveGlasses="van"},
            };
        }

        public void Add(Person p)
        {
            this.People.Add(p);
        }

        public void ChangeGlassesForAll()
        {
            foreach (Person p in this.People)
            {
                p.ChangeGlasses();
            }
        }
    }
}
