﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BombDeactivation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        const int BOMB_COUNT = 10;
        const int MAX_TIME = 5;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void BombClick(object sender, MouseButtonEventArgs e)
        {
            if (e.Source is Label l)
            {
                string buttonContent = l.Content.ToString() ?? "-0";
                string buttonId = buttonContent.Substring(buttonContent.IndexOf("-") + 1);
                int wireId = (int.Parse(buttonId) - 1) % Enum.GetValues(typeof(Wire)).Length; // 4 = Enum.GetValues(typeof(Wire)).Length
                Wire deactivationWire = (Wire)wireId;
                BombWindow bw = new BombWindow(deactivationWire, MAX_TIME);
                if (bw.ShowDialog() == true) // success
                {
                    l.BorderBrush = Brushes.DarkGreen;
                }
                else // bomb exploded
                {
                    l.BorderBrush = Brushes.IndianRed;
                }
                l.BorderThickness = new Thickness(8);
                l.IsEnabled = false;
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < BOMB_COUNT; i++)
            {
                Label l = new Label
                {
                    Content = $"Bomb-{i + 1}",
                    FontSize = 20,
                    Background = Brushes.LightBlue,
                    Margin = new Thickness(20),
                    Width = 100,
                    Height = 70,
                    HorizontalContentAlignment = HorizontalAlignment.Center,
                    VerticalContentAlignment = VerticalAlignment.Center
                };
                this.wp_bombs.Children.Add(l);
            }
        }
    }

    public enum Wire
    {
        Blue,
        Green,
        Red,
        Yellow,
    }
}