﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace BombDeactivation
{
    /// <summary>
    /// Interaction logic for BombWindow.xaml
    /// </summary>
    public partial class BombWindow : Window
    {
        int maxTime;
        Wire deactivationWire;
        DispatcherTimer timer;

        //static Wire[] wireOptions = new Wire[]
        //    {
        //        Wire.Blue,
        //        Wire.Green,
        //        Wire.Red,
        //        Wire.Yellow,
        //    };
        //static Brush[] bgColors = new Brush[]
        //{
        //        Brushes.LightBlue,
        //        Brushes.LightGreen,
        //        Brushes.PaleVioletRed,
        //        Brushes.LightYellow,
        //};

        Dictionary<Wire, Brush> wireOptions = new Dictionary<Wire, Brush>(
            [
                new KeyValuePair<Wire, Brush>(Wire.Blue, Brushes.LightBlue),
                new KeyValuePair<Wire, Brush>(Wire.Green, Brushes.LightGreen),
                new KeyValuePair<Wire, Brush>(Wire.Red, Brushes.PaleVioletRed),
                new KeyValuePair<Wire, Brush>(Wire.Yellow, Brushes.LightYellow),
            ]);

        public BombWindow(Wire deactivationWire, int maxTime)
        {
            InitializeComponent();

            this.maxTime = maxTime;
            this.deactivationWire = deactivationWire;
            timer = new DispatcherTimer();
        }

        private void WireOptionClick(object sender, MouseButtonEventArgs e)
        {
            if (e.Source is Label b &&
                b.Content is Wire wire)
            {
                timer.Stop();
                if (wire == this.deactivationWire)
                    this.DialogResult = true;
                else
                    this.DialogResult = false;
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var wires = wireOptions.Keys.ToList();
            var bgColors = wireOptions.Values.ToList();
            for (int i = 0; i < wires.Count; i++)
            {
                Label l = new Label
                {
                    Content = wires[i],
                    Background = bgColors[i],
                    FontSize = 20,
                    Margin = new Thickness(20),
                    Width = 80,
                    Height = 50,
                    HorizontalContentAlignment = HorizontalAlignment.Center,
                    VerticalContentAlignment = VerticalAlignment.Center
                };
                this.wp_wireOptions.Children.Add(l);
            }

            this.lb_time.Content = maxTime;

            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += (_, _) =>
            {
                var remainingTime = (int)lb_time.Content - 1;
                this.lb_time.Content = remainingTime;
                if (remainingTime == 0)
                {
                    timer.Stop();
                    this.DialogResult = false;
                }
            };
            timer.Start();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (timer.IsEnabled) // vagy: this.DialogResult == null
            {
                timer.IsEnabled = false;
                var result = MessageBox.Show("Biztos benne?", "Bezárás", MessageBoxButton.YesNoCancel, MessageBoxImage.Warning);
                timer.IsEnabled = true;
                if (result == MessageBoxResult.Yes)
                {
                    timer.Stop();
                    this.DialogResult = false;
                }
                else
                {
                    e.Cancel = true;
                }
            }
        }
    }
}
