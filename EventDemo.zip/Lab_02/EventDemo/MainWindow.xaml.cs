﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EventDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void MainPreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            var source = e.Source;
            var originalSource = e.OriginalSource;
            ;
            if (sender is Window)
                e.Handled = true;
        }

        private void MainMouseDown(object sender, MouseButtonEventArgs e)
        {
            var source = e.Source;
            var originalSource = e.OriginalSource;
            ;
        }
    }
}